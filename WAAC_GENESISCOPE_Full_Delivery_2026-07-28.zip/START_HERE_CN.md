# 从这里开始：WAAC GENESISCOPE OS

## 1. 系统解决什么问题

意识研究并不缺少理论名称，真正缺少的是：

1. 每种理论究竟保存什么本质差异；
2. 哪项观测能够把相邻理论区分开；
3. 不同用途需要重新打开哪些完整来源；
4. 世界人工意识科学院如何把专家档案组织为共同实验；
5. 公众如何理解AI表现、候选机制、意识判断、道德地位和法律身份之间的断点。

## 2. 安装与启动

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -e .
waac-genesiscope verify
waac-genesiscope serve --port 8771
```

浏览器打开：`http://127.0.0.1:8771`

## 3. 常用命令

```bash
waac-genesiscope summary
waac-genesiscope families
waac-genesiscope search "Integrated Information"
waac-genesiscope compare 61 106 --purpose expert
waac-genesiscope experts --family F06
waac-genesiscope path P30
```

## 4. 两种数量口径

- `432`：当前All Landscape Theories页面逐一链接的条目数；
- `over 450`：官网对总体理论规模的自述，可能包含Additional Theories聚合页内部条目。

系统同时保留两个口径，不把它们强行合并。

## 5. 重要边界

本系统不认证任何理论为真，不替任何专家表态，不认定当前AI具有意识，不把标题级分类用于临床、伦理、法律或政策决定。
